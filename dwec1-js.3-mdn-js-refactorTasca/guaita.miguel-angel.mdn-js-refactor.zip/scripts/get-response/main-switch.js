function getResponse(score,isMachineOn){
    let response;
    if (isMachineOn) {
        response = "Machine is active";
        //this is too long, not easy and it's not a goog practice...
        //for real, I did this switch by hand, and I don't recommend it
        //to anybody.
        switch(score){
            case 1:
                response="That was a terrible score - total fail!";
            break;
            case 2:
                response="That was a terrible score - total fail!";
            break;
            case 3:
                response="That was a terrible score - total fail!";
            break;
            case 4:
                response="That was a terrible score - total fail!";
            break;
            case 5:
                response="That was a terrible score - total fail!";
            break;
            case 6:
                response="That was a terrible score - total fail!";
            break;
            case 7:
                response="That was a terrible score - total fail!";
            break;
            case 8:
                response="That was a terrible score - total fail!";
            break;
            case 9:
                response="That was a terrible score - total fail!";
            break;
            case 10:
                response="That was a terrible score - total fail!";
            break;
            case 11:
                response="That was a terrible score - total fail!";
            break;
            case 12:
                response="That was a terrible score - total fail!";
            break;
            case 13:
                response="That was a terrible score - total fail!";
            break;
            case 14:
                response="That was a terrible score - total fail!";
            break;
            case 15:
                response="That was a terrible score - total fail!";
            break;
            case 16:
                response="That was a terrible score - total fail!";
            break;
            case 17:
                response="That was a terrible score - total fail!";
            break;
            case 18:
                response="That was a terrible score - total fail!";
            break;
            case 19:
                response="That was a terrible score - total fail!";
            break;
            case 20:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 21:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 22:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 23:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 24:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 25:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 26:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 27:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 28:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 29:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 30:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 31:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 32:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 33:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 34:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 35:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 36:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 37:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 38:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 39:
                response = "You know some things, but it's a pretty bad score. Needs improvement";
            break;
            case 40:
                response="You did a passable job, not bad!";
            break;
            case 41:
                response="You did a passable job, not bad!";
            break;
            case 42:
                response="You did a passable job, not bad!";
            break;
            case 43:
                response="You did a passable job, not bad!";
            break;
            case 44:
                response="You did a passable job, not bad!";
            break;
            case 45:
                response="You did a passable job, not bad!";
            break;
            case 46:
                response="You did a passable job, not bad!";
            break;
            case 47:
                response="You did a passable job, not bad!";
            break;
            case 48:
                response="You did a passable job, not bad!";
            break;
            case 49:
                response="You did a passable job, not bad!";
            break;
            case 50:
                response="You did a passable job, not bad!";
            break;
            case 51:
                response="You did a passable job, not bad!";
            break;
            case 52:
                response="You did a passable job, not bad!";
            break;
            case 53:
                response="You did a passable job, not bad!";
            break;
            case 54:
                response="You did a passable job, not bad!";
            break;
            case 55:
                response="You did a passable job, not bad!";
            break;
            case 56:
                response="You did a passable job, not bad!";
            break;
            case 57:
                response="You did a passable job, not bad!";
            break;
            case 58:
                response="You did a passable job, not bad!";
            break;
            case 59:
                response="You did a passable job, not bad!";
            break;
            case 60:
                response="You did a passable job, not bad!";
            break;
            case 61:
                response="You did a passable job, not bad!";
            break;
            case 62:
                response="You did a passable job, not bad!";
            break;
            case 63:
                response="You did a passable job, not bad!";
            break;
            case 64:
                response="You did a passable job, not bad!";
            break;
            case 65:
                response="You did a passable job, not bad!";
            break;
            case 66:
                response="You did a passable job, not bad!";
            break;
            case 67:
                response="You did a passable job, not bad!";
            break;
            case 68:
                response="You did a passable job, not bad!";
            break;
            case 69:
                response="You did a passable job, not bad!";
            break;
            case 70:
                response = "That's a great score, you really know your stuff.";
            break;
            case 71:
                response = "That's a great score, you really know your stuff.";
            break;
            case 72:
                response = "That's a great score, you really know your stuff.";
            break;
            case 73:
                response = "That's a great score, you really know your stuff.";
            break;
            case 74:
                response = "That's a great score, you really know your stuff.";
            break;
            case 75:
                response = "That's a great score, you really know your stuff.";
            break;
            case 76:
                response = "That's a great score, you really know your stuff.";
            break;
            case 77:
                response = "That's a great score, you really know your stuff.";
            break;
            case 78:
                response = "That's a great score, you really know your stuff.";
            break;
            case 79:
                response = "That's a great score, you really know your stuff.";
            break;
            case 80:
                response = "That's a great score, you really know your stuff.";
            break;
            case 81:
                response = "That's a great score, you really know your stuff.";
            break;
            case 82:
                response = "That's a great score, you really know your stuff.";
            break;
            case 83:
                response = "That's a great score, you really know your stuff.";
            break;
            case 84:
                response = "That's a great score, you really know your stuff.";
            break;
            case 85:
                response = "That's a great score, you really know your stuff.";
            break;
            case 86:
                response = "That's a great score, you really know your stuff.";
            break;
            case 87:
                response = "That's a great score, you really know your stuff.";
            break;
            case 88:
                response = "That's a great score, you really know your stuff.";
            break;
            case 89:
                response = "That's a great score, you really know your stuff.";
            break;
            case 90:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 91:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 92:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 93:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 94:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 95:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 96:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 97:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 98:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 99:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            case 100:
                response="What an amazing score! Did you cheat? Are you for real?";
            break;
            default:
                response = "This is not possible, an error has occurred";
            break;
        }
    } else response = "Machine isn't active. Switch it on.";
    return response;
}

